<?php

namespace KitchenManager\Modules\Products\Admin;

use KitchenManager\Modules\Products\Services\ProductService;
use KitchenManager\Modules\Recipes\Services\RecipeService;
use KitchenManager\Modules\Ingredients\Services\IngredientService;

class ProductsPage 
{
    private ProductService $service;
    private RecipeService $recipeService;
    private IngredientService $ingredientService;

    public function __construct() 
    {
        $this->service           = new ProductService();
        $this->recipeService     = new RecipeService();
        $this->ingredientService = new IngredientService();
    }

    public function registerMenu(): void 
    {
        add_submenu_page(
            'kitchen-manager',
            'Catálogo de Produtos & Kits',
            'Produtos & Kits',
            'manage_options',
            'kitchen-manager-products',
            [$this, 'render'],
            4
        );
    }

    public function handleSave(): void 
    {
        if (!current_user_can('manage_options')) {
            wp_die('Acesso não autorizado.');
        }

        check_admin_referer('km_save_product_action', 'km_product_nonce');

        $this->service->saveProduct($_POST);
        wp_safe_redirect(admin_url('admin.php?page=kitchen-manager-products&status=saved'));
        exit;
    }

    public function handleDelete(): void 
    {
        if (!current_user_can('manage_options')) {
            wp_die('Acesso não autorizado.');
        }

        $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        check_admin_referer('km_delete_product_' . $id);

        $this->service->deleteProduct($id);
        wp_safe_redirect(admin_url('admin.php?page=kitchen-manager-products&status=deleted'));
        exit;
    }

    public function render(): void 
    {
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'list';
        $status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';

        if ($action === 'new' || $action === 'edit') {
            $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
            $product     = $id > 0 ? $this->service->getProduct($id) : null;
            $recipes     = $this->recipeService->getRecipes();
            $ingredients = $this->ingredientService->getIngredients();
            $roles       = ProductService::ROLES;

            require_once KM_PLUGIN_DIR . 'modules/Products/Views/product-form.php';
        } else {
            $products = $this->service->getProducts();
            require_once KM_PLUGIN_DIR . 'modules/Products/Views/products-list.php';
        }
    }
}