<?php
if (!defined('ABSPATH')) exit;

$isEdit = !empty($product);
$initialTitle = $isEdit ? 'Editar Produto: ' . esc_html($product->name) : 'Novo Produto Comercial / Kit';
$items = $product->items ?? [];
?>

<div class="wrap km-products-wrap">
    
    <div style="margin-bottom: 18px;">
        <a href="<?php echo esc_url(admin_url('admin.php?page=kitchen-manager-products')); ?>" style="text-decoration: none; font-size: 13px;">
            ← Voltar para o Catálogo de Produtos
        </a>
        <h1 id="km-page-dynamic-title" style="margin: 8px 0 4px 0;"><?php echo $initialTitle; ?></h1>
        <p style="margin: 0; color: #646970;">Formate a composição física e culinária deste item para determinar seu custo real e margem de venda.</p>
    </div>

    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="km-product-form">
        <input type="hidden" name="action" value="km_save_product">
        <input type="hidden" name="id" value="<?php echo $isEdit ? (int) $product->id : 0; ?>">
        <?php wp_nonce_field('km_save_product_action', 'km_product_nonce'); ?>

        <div class="km-form-layout">
            
            <!-- COLUNA PRINCIPAL -->
            <div class="km-main-col">
                
                <!-- DADOS BÁSICOS -->
                <div class="km-card">
                    <h2 class="km-card-title">1. Identificação do Produto</h2>
                    <div class="km-field">
                        <label for="km-p-name">Nome do Produto Comercial:</label>
                        <input type="text" id="km-p-name" name="name" value="<?php echo $isEdit ? esc_attr($product->name) : ''; ?>" placeholder="Ex: Caixa Presente com 6 Brigadeiros Gourmet" required class="km-input-text" style="font-size: 15px; font-weight: 600;">
                        <small>Como este item será apresentado ao cliente no cardápio ou delivery.</small>
                    </div>
                </div>

                <!-- COMPOSIÇÃO: FICHAS TÉCNICAS -->
                <div class="km-card" style="margin-top: 18px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <h2 class="km-card-title" style="margin: 0;">🍳 2. Fichas Técnicas Integradas (Receitas)</h2>
                        <button type="button" class="button button-secondary button-small" id="km-add-recipe-row">➕ Adicionar Receita</button>
                    </div>
                    <p style="font-size: 13px; color: #646970; margin-top: 0;">Selecione as receitas e quantas porções/unidades compõem este produto.</p>

                    <div id="km-recipes-list" class="km-repeater-list">
                        <?php 
                        $recipeItemIdx = 0;
                        if (!empty($items)):
                            foreach ($items as $it): 
                                if ($it->item_type !== 'recipe') continue;
                        ?>
                            <div class="km-repeater-row km-row-recipe">
                                <input type="hidden" name="items[<?php echo $recipeItemIdx; ?>][item_type]" value="recipe">
                                <select name="items[<?php echo $recipeItemIdx; ?>][item_id]" class="km-select-item km-recipe-select" required>
                                    <option value="">— Selecione a Ficha Técnica —</option>
                                    <?php foreach ($recipes as $r): ?>
                                        <option value="<?php echo esc_attr($r->id); ?>" data-cost="<?php echo esc_attr($r->unitCost); ?>" <?php echo ($it->item_id == $r->id) ? 'selected' : ''; ?>>
                                            <?php echo esc_html($r->name); ?> (Custo Unit: R$ <?php echo number_format($r->unitCost, 2, ',', '.'); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="km-qty-wrap">
                                    <input type="number" name="items[<?php echo $recipeItemIdx; ?>][quantity]" value="<?php echo esc_attr((float) $it->quantity); ?>" step="0.1" min="0.1" placeholder="Qtd" class="km-input-qty" required>
                                    <span>porções</span>
                                </div>
                                <span class="km-row-cost-preview">R$ <?php echo number_format($it->total_cost, 2, ',', '.'); ?></span>
                                <button type="button" class="km-del-btn" title="Remover">✕</button>
                            </div>
                        <?php 
                            $recipeItemIdx++;
                            endforeach; 
                        endif;
                        ?>
                    </div>
                </div>

                <!-- COMPOSIÇÃO: EMBALAGENS, FLORES E ACESSÓRIOS -->
                <div class="km-card" style="margin-top: 18px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <h2 class="km-card-title" style="margin: 0;">📦 3. Embalagens, Flores & Finalização</h2>
                        <button type="button" class="button button-secondary button-small" id="km-add-ing-row">➕ Adicionar Embalagem / Flor</button>
                    </div>
                    <p style="font-size: 13px; color: #646970; margin-top: 0;">Insumos físicos que acompanham este produto (caixas, laços, tags, flores).</p>

                    <div id="km-ings-list" class="km-repeater-list">
                        <?php 
                        $ingItemIdx = $recipeItemIdx + 100;
                        if (!empty($items)):
                            foreach ($items as $it): 
                                if ($it->item_type !== 'ingredient') continue;
                        ?>
                            <div class="km-repeater-row km-row-ingredient">
                                <input type="hidden" name="items[<?php echo $ingItemIdx; ?>][item_type]" value="ingredient">
                                <select name="items[<?php echo $ingItemIdx; ?>][item_id]" class="km-select-item km-ing-select" required>
                                    <option value="">— Selecione o Insumo / Embalagem —</option>
                                    <?php foreach ($ingredients as $ing): 
                                        $unitCost = ($ing->package_size > 0) ? ($ing->package_cost / $ing->package_size) : 0;
                                    ?>
                                        <option value="<?php echo esc_attr($ing->id); ?>" data-cost="<?php echo esc_attr($unitCost); ?>" data-unit="<?php echo esc_attr($ing->unit); ?>" <?php echo ($it->item_id == $ing->id) ? 'selected' : ''; ?>>
                                            [<?php echo esc_html(strtoupper($ing->category)); ?>] <?php echo esc_html($ing->name); ?> (R$ <?php echo number_format($unitCost, 2, ',', '.'); ?>/<?php echo esc_html($ing->unit); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="km-qty-wrap">
                                    <input type="number" name="items[<?php echo $ingItemIdx; ?>][quantity]" value="<?php echo esc_attr((float) $it->quantity); ?>" step="0.01" min="0.01" placeholder="Qtd" class="km-input-qty" required>
                                    <span class="km-unit-dynamic"><?php echo esc_html($it->unit ?? 'un'); ?></span>
                                </div>
                                <span class="km-row-cost-preview">R$ <?php echo number_format($it->total_cost, 2, ',', '.'); ?></span>
                                <button type="button" class="km-del-btn" title="Remover">✕</button>
                            </div>
                        <?php 
                            $ingItemIdx++;
                            endforeach; 
                        endif;
                        ?>
                    </div>
                </div>

                <!-- ESTRATÉGIA COMERCIAL & PREÇO -->
                <div class="km-card" style="margin-top: 18px;">
                    <h2 class="km-card-title">4. Estratégia de Mercado & Preço</h2>

                    <div class="km-field">
                        <label for="km-p-role">Papel Estratégico do Produto (Label):</label>
                        <select id="km-p-role" name="strategic_role" class="km-input-text" style="height: 38px;">
                            <?php foreach ($roles as $key => $r): ?>
                                <option value="<?php echo esc_attr($key); ?>" 
                                        data-margin="<?php echo esc_attr($r['suggested_margin']); ?>"
                                        data-desc="<?php echo esc_attr($r['desc']); ?>"
                                        <?php echo ($isEdit && $product->strategic_role === $key) ? 'selected' : ''; ?>>
                                    <?php echo esc_html($r['label']); ?> — (Meta: <?php echo $r['suggested_margin']; ?>%)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div id="km-role-explanation" class="km-role-box">
                            <!-- Inserido dinamicamente via JS -->
                        </div>
                    </div>

                    <div class="km-grid-2col" style="margin-top: 14px;">
                        <div class="km-field">
                            <label for="km-p-margin">Meta de Margem Alvo (%):</label>
                            <input type="number" id="km-p-margin" name="target_margin" value="<?php echo $isEdit ? esc_attr((float) $product->target_margin) : '30'; ?>" step="0.1" min="1" max="90" required class="km-input-text">
                        </div>

                        <div class="km-field">
                            <label for="km-p-price">Preço de Venda Praticado [R$]:</label>
                            <input type="number" id="km-p-price" name="sale_price" value="<?php echo $isEdit ? esc_attr(number_format($product->sale_price, 2, '.', '')) : '0.00'; ?>" step="0.01" min="0" class="km-input-text" style="font-weight: bold; color: #2271b1; font-size: 16px;">
                        </div>
                    </div>

                    <button type="submit" class="button button-primary button-large" style="width: 100%; height: 46px; font-size: 15px; margin-top: 14px;">
                        💾 Salvar Produto Comercial
                    </button>
                </div>

            </div>

            <!-- LATERAL: RESUMO FINANCEIRO EM TEMPO REAL -->
            <div class="km-side-col">
                <div class="km-card km-sticky-side">
                    <h2 class="km-card-title">📊 Resumo de Custos & Margem</h2>

                    <div class="km-sum-row">
                        <span>Custo das Fichas Culinárias:</span>
                        <strong id="km-sum-recipes">R$ 0,00</strong>
                    </div>
                    <div class="km-sum-row">
                        <span>Embalagens & Acessórios:</span>
                        <strong id="km-sum-ings">R$ 0,00</strong>
                    </div>
                    <div class="km-sum-row km-sum-total">
                        <span><strong>Custo Direto Total:</strong></span>
                        <strong id="km-sum-total" style="color: #1d2327; font-size: 18px;">R$ 0,00</strong>
                    </div>

                    <div id="km-status-box" class="km-live-box" style="margin-top: 18px;">
                        <span class="km-live-tag" id="km-live-tag">Margem Real</span>
                        <strong class="km-live-val" id="km-live-val">0.0%</strong>
                        <p id="km-live-desc" style="margin: 6px 0 0 0; font-size: 12.5px; line-height: 1.4;">
                            Informe o preço para ver a margem real.
                        </p>
                    </div>

                    <div class="km-tip-box" style="margin-top: 16px;">
                        <strong>💡 Dica do Chef:</strong>
                        <p style="margin: 4px 0 0 0; font-size: 12px; color: #50575e; line-height: 1.4;">
                            Ao salvar o produto com suas embalagens e fichas, o sistema recalculará sua margem automaticamente sempre que o preço de qualquer insumo mudar!
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </form>
</div>

<style>
.km-products-wrap { max-width: 1240px; margin-top: 20px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
.km-form-layout { display: grid; grid-template-columns: 1fr 380px; gap: 20px; }
.km-card { background: #fff; border: 1px solid #ccd0d4; padding: 22px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.03); }
.km-card-title { font-size: 15px; margin: 0 0 14px 0; color: #1d2327; font-weight: 700; }
.km-field label { display: block; font-weight: 600; font-size: 13px; margin-bottom: 5px; color: #2c3338; }
.km-field small { display: block; color: #646970; font-size: 12px; margin-top: 4px; }
.km-input-text { width: 100%; padding: 8px 10px; border: 1px solid #8c8f94; border-radius: 4px; box-sizing: border-box; }
.km-grid-2col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }

/* Repeaters */
.km-repeater-list { display: flex; flex-direction: column; gap: 8px; }
.km-repeater-row { display: flex; align-items: center; gap: 8px; background: #fdfdfd; border: 1px solid #e2e4e7; padding: 8px 12px; border-radius: 6px; }
.km-select-item { flex: 1; padding: 6px 8px; border: 1px solid #8c8f94; border-radius: 4px; }
.km-qty-wrap { display: flex; align-items: center; width: 130px; gap: 4px; }
.km-input-qty { width: 65px; padding: 6px; border: 1px solid #8c8f94; border-radius: 4px; }
.km-qty-wrap span { font-size: 12px; color: #646970; }
.km-row-cost-preview { width: 85px; font-weight: 700; font-size: 13px; text-align: right; color: #1d2327; }
.km-del-btn { background: none; border: none; color: #b32d2e; font-weight: bold; cursor: pointer; font-size: 15px; padding: 4px; }

/* Papel e Explicação */
.km-role-box { background: #f0f6fc; border-left: 3px solid #2271b1; padding: 10px 12px; border-radius: 0 4px 4px 0; margin-top: 8px; font-size: 12px; color: #2c3338; line-height: 1.4; }

/* Lateral */
.km-sticky-side { position: sticky; top: 32px; }
.km-sum-row { display: flex; justify-content: space-between; font-size: 13px; padding: 6px 0; color: #50575e; }
.km-sum-total { border-top: 2px solid #ccd0d4; padding-top: 10px; margin-top: 6px; }
.km-live-box { padding: 14px; border-radius: 6px; }
.km-live-tag { display: block; font-size: 11px; text-transform: uppercase; font-weight: 700; }
.km-live-val { display: block; font-size: 26px; margin-top: 2px; }
.km-tip-box { background: #fcf9e8; border: 1px solid #dfd69d; border-radius: 6px; padding: 12px; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const nameInput     = document.getElementById('km-p-name');
    const dynamicTitle  = document.getElementById('km-page-dynamic-title');
    const roleSelect    = document.getElementById('km-p-role');
    const roleExpl      = document.getElementById('km-role-explanation');
    const marginInput   = document.getElementById('km-p-margin');
    const priceInput    = document.getElementById('km-p-price');

    const sumRecipesEl  = document.getElementById('km-sum-recipes');
    const sumIngsEl     = document.getElementById('km-sum-ings');
    const sumTotalEl    = document.getElementById('km-sum-total');
    const statusBox     = document.getElementById('km-status-box');
    const liveTag       = document.getElementById('km-live-tag');
    const liveVal       = document.getElementById('km-live-val');
    const liveDesc      = document.getElementById('km-live-desc');

    const recipesList   = document.getElementById('km-recipes-list');
    const ingsList      = document.getElementById('km-ings-list');
    const addRecipeBtn  = document.getElementById('km-add-recipe-row');
    const addIngBtn     = document.getElementById('km-add-ing-row');

    // 1. Título Reativo em Tempo Real
    nameInput.addEventListener('input', function () {
        const val = nameInput.value.trim();
        dynamicTitle.textContent = val ? 'Editar Produto: ' + val : 'Novo Produto Comercial / Kit';
    });

    // 2. Explicação Dinâmica do Papel Estratégico
    function updateRoleExplanation() {
        const opt = roleSelect.options[roleSelect.selectedIndex];
        if (opt) {
            roleExpl.textContent = opt.getAttribute('data-desc') || '';
        }
    }
    roleSelect.addEventListener('change', function () {
        const opt = roleSelect.options[roleSelect.selectedIndex];
        if (opt) {
            marginInput.value = opt.getAttribute('data-margin') || 30;
            updateRoleExplanation();
            recalculateTotals();
        }
    });
    updateRoleExplanation();

    // 3. Recálculo Geral de Custos e Margem
    function recalculateTotals() {
        let recipesCost = 0;
        document.querySelectorAll('.km-row-recipe').forEach(row => {
            const sel = row.querySelector('.km-recipe-select');
            const qty = parseFloat(row.querySelector('.km-input-qty').value) || 0;
            const cost = sel && sel.selectedIndex >= 0 ? (parseFloat(sel.options[sel.selectedIndex].getAttribute('data-cost')) || 0) : 0;
            const rowTotal = cost * qty;
            recipesCost += rowTotal;
            row.querySelector('.km-row-cost-preview').textContent = 'R$ ' + rowTotal.toFixed(2).replace('.', ',');
        });

        let ingsCost = 0;
        document.querySelectorAll('.km-row-ingredient').forEach(row => {
            const sel = row.querySelector('.km-ing-select');
            const qty = parseFloat(row.querySelector('.km-input-qty').value) || 0;
            const cost = sel && sel.selectedIndex >= 0 ? (parseFloat(sel.options[sel.selectedIndex].getAttribute('data-cost')) || 0) : 0;
            const unit = sel && sel.selectedIndex >= 0 ? sel.options[sel.selectedIndex].getAttribute('data-unit') : 'un';
            const unitEl = row.querySelector('.km-unit-dynamic');
            if (unitEl && unit) unitEl.textContent = unit;

            const rowTotal = cost * qty;
            ingsCost += rowTotal;
            row.querySelector('.km-row-cost-preview').textContent = 'R$ ' + rowTotal.toFixed(2).replace('.', ',');
        });

        const totalCost = recipesCost + ingsCost;
        const salePrice = parseFloat(priceInput.value) || 0;
        const targetMargin = parseFloat(marginInput.value) || 30;

        sumRecipesEl.textContent = 'R$ ' + recipesCost.toFixed(2).replace('.', ',');
        sumIngsEl.textContent    = 'R$ ' + ingsCost.toFixed(2).replace('.', ',');
        sumTotalEl.textContent   = 'R$ ' + totalCost.toFixed(2).replace('.', ',');

        if (salePrice > 0) {
            const netProfit = salePrice - totalCost;
            const realMargin = (netProfit / salePrice) * 100;

            liveVal.textContent = realMargin.toFixed(1).replace('.', ',') + '%';

            if (netProfit < 0 || realMargin < 5) {
                statusBox.style.background = '#fcf0f1';
                statusBox.style.borderLeft = '4px solid #d63638';
                liveTag.textContent = '🚨 Margem Crítica / Prejuízo';
                liveTag.style.color = '#b32d2e';
                liveVal.style.color = '#b32d2e';
                liveDesc.innerHTML = `Você está perdendo <strong>R$ ${Math.abs(netProfit).toFixed(2).replace('.', ',')}</strong> por unidade vendida.`;
            } else if (realMargin < targetMargin) {
                statusBox.style.background = '#fdf9e2';
                statusBox.style.borderLeft = '4px solid #dba617';
                liveTag.textContent = '⚠️ Margem Abaixo da Meta';
                liveTag.style.color = '#8a6d00';
                liveVal.style.color = '#8a6d00';
                liveDesc.innerHTML = `Lucro de <strong>R$ ${netProfit.toFixed(2).replace('.', ',')}</strong> por unidade (Meta era ${targetMargin}%).`;
            } else {
                statusBox.style.background = '#f0f8f1';
                statusBox.style.borderLeft = '4px solid #007017';
                liveTag.textContent = '✅ Margem Saudável';
                liveTag.style.color = '#007017';
                liveVal.style.color = '#007017';
                liveDesc.innerHTML = `Lucro limpo de <strong>R$ ${netProfit.toFixed(2).replace('.', ',')}</strong> por unidade vendida.`;
            }
        } else {
            statusBox.style.background = '#f0f6fc';
            statusBox.style.borderLeft = '4px solid #2271b1';
            liveTag.textContent = 'Aguardando Preço';
            liveTag.style.color = '#2271b1';
            liveVal.style.color = '#2271b1';
            liveVal.textContent = '0.0%';
            liveDesc.textContent = 'Defina o preço de venda para calcular.';
        }
    }

    function bindRow(row) {
        row.querySelectorAll('select, input').forEach(el => {
            el.addEventListener('input', recalculateTotals);
            el.addEventListener('change', recalculateTotals);
        });
        const del = row.querySelector('.km-del-btn');
        if (del) {
            del.addEventListener('click', function () {
                row.remove();
                recalculateTotals();
            });
        }
    }

    document.querySelectorAll('.km-repeater-row').forEach(bindRow);
    marginInput.addEventListener('input', recalculateTotals);
    priceInput.addEventListener('input', recalculateTotals);

    // 4. Adição de Novas Linhas
    if (addRecipeBtn) {
        addRecipeBtn.addEventListener('click', function () {
            const idx = Date.now();
            const div = document.createElement('div');
            div.className = 'km-repeater-row km-row-recipe';
            div.innerHTML = `
                <input type="hidden" name="items[${idx}][item_type]" value="recipe">
                <select name="items[${idx}][item_id]" class="km-select-item km-recipe-select" required>
                    <option value="">— Selecione a Ficha Técnica —</option>
                    <?php foreach ($recipes as $r): ?>
                        <option value="<?php echo esc_attr($r->id); ?>" data-cost="<?php echo esc_attr($r->unitCost); ?>">
                            <?php echo esc_html($r->name); ?> (Custo Unit: R$ <?php echo number_format($r->unitCost, 2, ',', '.'); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <div class="km-qty-wrap">
                    <input type="number" name="items[${idx}][quantity]" value="1" step="0.1" min="0.1" placeholder="Qtd" class="km-input-qty" required>
                    <span>porções</span>
                </div>
                <span class="km-row-cost-preview">R$ 0,00</span>
                <button type="button" class="km-del-btn" title="Remover">✕</button>
            `;
            recipesList.appendChild(div);
            bindRow(div);
            recalculateTotals();
        });
    }

    if (addIngBtn) {
        addIngBtn.addEventListener('click', function () {
            const idx = Date.now();
            const div = document.createElement('div');
            div.className = 'km-repeater-row km-row-ingredient';
            div.innerHTML = `
                <input type="hidden" name="items[${idx}][item_type]" value="ingredient">
                <select name="items[${idx}][item_id]" class="km-select-item km-ing-select" required>
                    <option value="">— Selecione o Insumo / Embalagem —</option>
                    <?php foreach ($ingredients as $ing): 
                        $unitCost = ($ing->package_size > 0) ? ($ing->package_cost / $ing->package_size) : 0;
                    ?>
                        <option value="<?php echo esc_attr($ing->id); ?>" data-cost="<?php echo esc_attr($unitCost); ?>" data-unit="<?php echo esc_attr($ing->unit); ?>">
                            [<?php echo esc_html(strtoupper($ing->category)); ?>] <?php echo esc_html($ing->name); ?> (R$ <?php echo number_format($unitCost, 2, ',', '.'); ?>/<?php echo esc_html($ing->unit); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <div class="km-qty-wrap">
                    <input type="number" name="items[${idx}][quantity]" value="1" step="0.01" min="0.01" placeholder="Qtd" class="km-input-qty" required>
                    <span class="km-unit-dynamic">un</span>
                </div>
                <span class="km-row-cost-preview">R$ 0,00</span>
                <button type="button" class="km-del-btn" title="Remover">✕</button>
            `;
            ingsList.appendChild(div);
            bindRow(div);
            recalculateTotals();
        });
    }

    recalculateTotals();
});
</script>