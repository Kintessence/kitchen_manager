<?php
if (!defined('ABSPATH')) exit;
$status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
?>

<div class="wrap km-ingredients-wrap">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <div>
            <h1>📦 Tabela Geral de Insumos & Custos</h1>
            <p class="description">Altere os preços diretamente nas linhas abaixo ou adicione novos insumos. O custo por grama/unidade é recalculado automaticamente.</p>
        </div>
        <div>
            <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=km_load_bakery_preset'), 'km_load_preset_action')); ?>" 
               class="button button-secondary"
               onclick="return confirm('Deseja carregar a lista de insumos clássicos de confeitaria?');">
                🎂 Carregar Preset de Confeitaria
            </a>
        </div>
    </div>

    <?php if ($status === 'saved'): ?>
        <div class="notice notice-success is-dismissible" style="margin-top: 15px;">
            <p><strong>✅ Todos os insumos e preços foram atualizados com sucesso!</strong></p>
        </div>
    <?php elseif ($status === 'preset_loaded'): ?>
        <div class="notice notice-success is-dismissible" style="margin-top: 15px;">
            <p><strong>✨ Lista de confeitaria carregada! Ajuste os preços conforme suas compras locais e salve.</strong></p>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="km-batch-form" style="margin-top: 15px;">
        <input type="hidden" name="action" value="km_save_ingredients_batch">
        <?php wp_nonce_field('km_save_ingredients_batch_action', 'km_ingredient_nonce'); ?>

        <div class="km-card">
            <table class="wp-list-table widefat fixed striped" id="km-repeater-table">
                <thead>
                    <tr>
                        <th style="width: 25%;">Nome do Insumo / Embalagem</th>
                        <th style="width: 10%;">Qtd Compra</th>
                        <th style="width: 15%;">Unid. Compra</th>
                        <th style="width: 12%;">Peso Líq. (g/ml)</th>
                        <th style="width: 15%;">Preço Pago (R$)</th>
                        <th style="width: 10%;">Unid. Uso</th>
                        <th style="width: 13%;">Custo Fracionado</th>
                    </tr>
                </thead>
                <tbody id="km-repeater-tbody">
                    <?php if (empty($ingredients)): ?>
                        <tr class="km-repeater-row">
                            <td>
                                <input type="hidden" name="ingredients[0][id]" value="">
                                <input type="text" name="ingredients[0][name]" placeholder="Ex: Leite Condensado" class="km-input-name" required>
                            </td>
                            <td><input type="number" name="ingredients[0][purchase_quantity]" value="1" step="0.01" min="0.01" class="km-input-qty"></td>
                            <td>
                                <select name="ingredients[0][purchase_unit]" class="km-select-punit">
                                    <option value="un">Unidade (un)</option>
                                    <option value="kg">Quilo (kg)</option>
                                    <option value="g">Grama (g)</option>
                                    <option value="l">Litro (l)</option>
                                    <option value="ml">Mililitro (ml)</option>
                                </select>
                            </td>
                            <td><input type="number" name="ingredients[0][net_weight]" value="395" step="0.01" placeholder="Se un/lata" class="km-input-net"></td>
                            <td><input type="number" name="ingredients[0][purchase_price]" value="8.50" step="0.01" min="0" class="km-input-price"></td>
                            <td>
                                <select name="ingredients[0][usage_unit]" class="km-select-uunit">
                                    <option value="g">Grama (g)</option>
                                    <option value="ml">Mililitro (ml)</option>
                                    <option value="un">Unidade (un)</option>
                                    <option value="kg">Quilo (kg)</option>
                                    <option value="l">Litro (l)</option>
                                </select>
                            </td>
                            <td class="km-col-fraction"><strong class="km-badge-fraction">R$ 0,0000</strong></td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($ingredients as $idx => $item): ?>
                            <tr class="km-repeater-row">
                                <td>
                                    <input type="hidden" name="ingredients[<?php echo $idx; ?>][id]" value="<?php echo esc_attr($item->id); ?>">
                                    <input type="text" name="ingredients[<?php echo $idx; ?>][name]" value="<?php echo esc_attr($item->name); ?>" class="km-input-name" required>
                                </td>
                                <td><input type="number" name="ingredients[<?php echo $idx; ?>][purchase_quantity]" value="<?php echo esc_attr($item->purchaseQuantity); ?>" step="0.01" min="0.01" class="km-input-qty"></td>
                                <td>
                                    <select name="ingredients[<?php echo $idx; ?>][purchase_unit]" class="km-select-punit">
                                        <option value="un" <?php selected($item->purchaseUnit, 'un'); ?>>Unidade (un)</option>
                                        <option value="kg" <?php selected($item->purchaseUnit, 'kg'); ?>>Quilo (kg)</option>
                                        <option value="g" <?php selected($item->purchaseUnit, 'g'); ?>>Grama (g)</option>
                                        <option value="l" <?php selected($item->purchaseUnit, 'l'); ?>>Litro (l)</option>
                                        <option value="ml" <?php selected($item->purchaseUnit, 'ml'); ?>>Mililitro (ml)</option>
                                    </select>
                                </td>
                                <td>
                                    <input type="number" name="ingredients[<?php echo $idx; ?>][net_weight]" 
                                           value="<?php echo ($item->purchaseUnit === 'un' && $item->conversionFactor > 1) ? esc_attr($item->conversionFactor) : ''; ?>" 
                                           step="0.01" placeholder="Se un/lata" class="km-input-net">
                                </td>
                                <td><input type="number" name="ingredients[<?php echo $idx; ?>][purchase_price]" value="<?php echo esc_attr($item->purchasePrice); ?>" step="0.01" min="0" class="km-input-price"></td>
                                <td>
                                    <select name="ingredients[<?php echo $idx; ?>][usage_unit]" class="km-select-uunit">
                                        <option value="g" <?php selected($item->usageUnit, 'g'); ?>>Grama (g)</option>
                                        <option value="ml" <?php selected($item->usageUnit, 'ml'); ?>>Mililitro (ml)</option>
                                        <option value="un" <?php selected($item->usageUnit, 'un'); ?>>Unidade (un)</option>
                                        <option value="kg" <?php selected($item->usageUnit, 'kg'); ?>>Quilo (kg)</option>
                                        <option value="l" <?php selected($item->usageUnit, 'l'); ?>>Litro (l)</option>
                                    </select>
                                </td>
                                <td class="km-col-fraction"><strong class="km-badge-fraction">R$ <?php echo number_format($item->unitUseCost, 4, ',', '.'); ?> / <?php echo esc_html($item->usageUnit); ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
                <button type="button" class="button" id="km-btn-add-row">➕ Adicionar Novo Insumo</button>
                <button type="submit" class="button button-primary button-large" style="font-size: 15px; padding: 0 24px;">💾 Salvar Todos os Preços</button>
            </div>
        </div>
    </form>
</div>

<style>
.km-ingredients-wrap { max-width: 1250px; margin-top: 20px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
.km-card { background: #fff; border: 1px solid #ccd0d4; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
#km-repeater-table input, #km-repeater-table select { width: 100%; padding: 6px; border: 1px solid #8c8f94; border-radius: 4px; }
.km-badge-fraction { color: #2271b1; font-size: 13px; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const tbody = document.getElementById('km-repeater-tbody');
    const addRowBtn = document.getElementById('km-btn-add-row');

    function calculateRow(row) {
        const qty = parseFloat(row.querySelector('.km-input-qty').value) || 0;
        const price = parseFloat(row.querySelector('.km-input-price').value) || 0;
        const netWeight = parseFloat(row.querySelector('.km-input-net').value) || 0;
        const pUnit = row.querySelector('.km-select-punit').value;
        const uUnit = row.querySelector('.km-select-uunit').value;
        const badge = row.querySelector('.km-badge-fraction');

        let factor = 1.0;
        if (pUnit === 'un' && (uUnit === 'g' || uUnit === 'ml')) {
            factor = netWeight > 0 ? netWeight : 1.0;
        } else if (pUnit === 'kg' && uUnit === 'g') {
            factor = 1000.0;
        } else if (pUnit === 'l' && uUnit === 'ml') {
            factor = 1000.0;
        } else if (pUnit === 'g' && uUnit === 'kg') {
            factor = 0.001;
        } else if (pUnit === 'ml' && uUnit === 'l') {
            factor = 0.001;
        }

        const totalBase = qty * factor;
        const unitCost = totalBase > 0 ? (price / totalBase) : 0;

        badge.textContent = 'R$ ' + unitCost.toFixed(4).replace('.', ',') + ' / ' + uUnit;
    }

    function bindRowEvents(row) {
        row.querySelectorAll('input, select').forEach(input => {
            input.addEventListener('input', () => calculateRow(row));
            input.addEventListener('change', () => calculateRow(row));
        });
        calculateRow(row);
    }

    document.querySelectorAll('.km-repeater-row').forEach(bindRowEvents);

    addRowBtn.addEventListener('click', function () {
        const nextIndex = tbody.children.length;
        const tr = document.createElement('tr');
        tr.className = 'km-repeater-row';
        tr.innerHTML = `
            <td>
                <input type="hidden" name="ingredients[${nextIndex}][id]" value="">
                <input type="text" name="ingredients[${nextIndex}][name]" placeholder="Nome do insumo..." class="km-input-name" required>
            </td>
            <td><input type="number" name="ingredients[${nextIndex}][purchase_quantity]" value="1" step="0.01" min="0.01" class="km-input-qty"></td>
            <td>
                <select name="ingredients[${nextIndex}][purchase_unit]" class="km-select-punit">
                    <option value="kg">Quilo (kg)</option>
                    <option value="g">Grama (g)</option>
                    <option value="un">Unidade (un)</option>
                    <option value="l">Litro (l)</option>
                    <option value="ml">Mililitro (ml)</option>
                </select>
            </td>
            <td><input type="number" name="ingredients[${nextIndex}][net_weight]" value="" step="0.01" placeholder="Se un/lata" class="km-input-net"></td>
            <td><input type="number" name="ingredients[${nextIndex}][purchase_price]" value="0.00" step="0.01" min="0" class="km-input-price"></td>
            <td>
                <select name="ingredients[${nextIndex}][usage_unit]" class="km-select-uunit">
                    <option value="g">Grama (g)</option>
                    <option value="ml">Mililitro (ml)</option>
                    <option value="un">Unidade (un)</option>
                    <option value="kg">Quilo (kg)</option>
                    <option value="l">Litro (l)</option>
                </select>
            </td>
            <td class="km-col-fraction"><strong class="km-badge-fraction">R$ 0,0000 / g</strong></td>
        `;
        tbody.appendChild(tr);
        bindRowEvents(tr);
    });
});
</script>