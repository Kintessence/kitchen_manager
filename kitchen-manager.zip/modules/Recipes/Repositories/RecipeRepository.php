<?php

namespace KitchenManager\Modules\Recipes\Repositories;

use KitchenManager\Modules\Recipes\DTOs\RecipeDTO;
use KitchenManager\Modules\Recipes\DTOs\RecipeItemDTO;

class RecipeRepository 
{
    private string $tableRecipes;
    private string $tableItems;

    public function __construct() 
    {
        global $wpdb;
        $this->tableRecipes = $wpdb->prefix . 'km_recipes';
        $this->tableItems   = $wpdb->prefix . 'km_recipe_items';
        $this->createTablesIfNotExists();
    }

    public function createTablesIfNotExists(): void 
    {
        global $wpdb;
        $charsetCollate = $wpdb->get_charset_collate();

        $sqlRecipes = "CREATE TABLE IF NOT EXISTS {$this->tableRecipes} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            yield_quantity DECIMAL(10, 4) NOT NULL DEFAULT 1.0000,
            total_batch_cost DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
            unit_portion_cost DECIMAL(10, 4) NOT NULL DEFAULT 0.0000,
            notes TEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) {$charsetCollate};";

        $sqlItems = "CREATE TABLE IF NOT EXISTS {$this->tableItems} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            recipe_id BIGINT(20) UNSIGNED NOT NULL,
            ingredient_id BIGINT(20) UNSIGNED NOT NULL,
            quantity DECIMAL(10, 4) NOT NULL DEFAULT 1.0000,
            measure_type VARCHAR(20) NOT NULL DEFAULT 'unit',
            cost DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
            PRIMARY KEY (id),
            KEY recipe_id (recipe_id)
        ) {$charsetCollate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sqlRecipes);
        dbDelta($sqlItems);
    }

    public function getAll(): array 
    {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->tableRecipes} ORDER BY name ASC");
        
        foreach ($rows as $row) {
            $row->yield = isset($row->yield_quantity) ? (float)$row->yield_quantity : 1.0;
        }

        return $rows;
    }

    public function getById(int $id): ?object 
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tableRecipes} WHERE id = %d", $id));
        if ($row) {
            $row->yield = isset($row->yield_quantity) ? (float)$row->yield_quantity : 1.0;
        }
        return $row ?: null;
    }

    public function getItemsByRecipeId(int $recipeId): array 
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->tableItems} WHERE recipe_id = %d", 
            $recipeId
        ));
    }

    // Alias para compatibilidade
    public function getItemsByRecipe(int $recipeId): array 
    {
        return $this->getItemsByRecipeId($recipeId);
    }

    public function save(RecipeDTO $dto): int 
    {
        global $wpdb;

        $data = [
            'name'              => $dto->name,
            'yield_quantity'    => $dto->yieldQuantity,
            'total_batch_cost'  => $dto->totalBatchCost,
            'unit_portion_cost' => $dto->unitPortionCost,
        ];

        if ($dto->id && $dto->id > 0) {
            $wpdb->update($this->tableRecipes, $data, ['id' => $dto->id]);
            return (int) $dto->id;
        } else {
            $wpdb->insert($this->tableRecipes, $data);
            return (int) $wpdb->insert_id;
        }
    }

    public function saveItem($dtoOrArray): bool 
    {
        global $wpdb;

        if (is_object($dtoOrArray)) {
            $data = [
                'recipe_id'     => $dtoOrArray->recipeId ?? $dtoOrArray->recipe_id,
                'ingredient_id' => $dtoOrArray->ingredientId ?? $dtoOrArray->ingredient_id,
                'quantity'      => $dtoOrArray->quantity ?? $dtoOrArray->quantityUsed,
                'measure_type'  => $dtoOrArray->measureType ?? $dtoOrArray->measure_type ?? 'unit',
                'cost'          => $dtoOrArray->cost ?? 0.0,
            ];
        } else {
            $data = [
                'recipe_id'     => (int) ($dtoOrArray['recipe_id'] ?? 0),
                'ingredient_id' => (int) ($dtoOrArray['ingredient_id'] ?? 0),
                'quantity'      => (float) ($dtoOrArray['quantity'] ?? 1),
                'measure_type'  => sanitize_key($dtoOrArray['measure_type'] ?? 'unit'),
                'cost'          => (float) ($dtoOrArray['cost'] ?? 0.0),
            ];
        }

        return (bool) $wpdb->insert($this->tableItems, $data);
    }

    public function deleteItemsByRecipeId(int $recipeId): bool 
    {
        global $wpdb;
        return (bool) $wpdb->delete($this->tableItems, ['recipe_id' => $recipeId]);
    }

    public function deleteItem(int $itemId): bool 
    {
        global $wpdb;
        return (bool) $wpdb->delete($this->tableItems, ['id' => $itemId]);
    }

    public function delete(int $id): bool 
    {
        global $wpdb;
        $this->deleteItemsByRecipeId($id);
        return (bool) $wpdb->delete($this->tableRecipes, ['id' => $id]);
    }
}