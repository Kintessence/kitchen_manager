<?php
if (!defined('ABSPATH')) exit;

$categories = $this->service->getCategories();
$status     = $status ?? (isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : '');
?>

<div class="wrap km-ingredients-wrap">
    <div class="km-header-bar">
        <div>
            <h1>📦 Cadastro e Custos de Insumos</h1>
            <p>Gerencie matérias-primas, embalagens, flores e fitas. O custo unitário é calculado automaticamente para as fichas e produtos.</p>
        </div>
        <div>
            <button type="button" class="button button-primary" id="km-add-row-btn">➕ Adicionar Insumo</button>
        </div>
    </div>

    <?php if ($status === 'saved'): ?>
        <div class="notice notice-success is-dismissible" style="margin-top: 15px;"><p><strong>✅ Insumos atualizados com sucesso!</strong></p></div>
    <?php elseif ($status === 'deleted'): ?>
        <div class="notice notice-info is-dismissible" style="margin-top: 15px;"><p><strong>🗑️ Insumo removido com sucesso.</strong></p></div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="km-ingredients-form" style="margin-top: 16px;">
        <input type="hidden" name="action" value="km_save_ingredients">
        <?php wp_nonce_field('km_save_ingredients_action', 'km_ingredients_nonce'); ?>

        <table class="wp-list-table widefat fixed striped" id="km-ingredients-table">
            <thead>
                <tr>
                    <th style="width: 24%;">Nome do Insumo</th>
                    <th style="width: 18%;">Categoria</th>
                    <th style="width: 14%;">Preço Embalagem</th>
                    <th style="width: 14%;">Qtd Embalagem</th>
                    <th style="width: 10%;">Unidade</th>
                    <th style="width: 12%;">Custo Unitário</th>
                    <th style="width: 8%; text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody id="km-ingredients-tbody">
                <?php if (empty($ingredients)): ?>
                    <tr class="km-row-empty">
                        <td colspan="7" style="text-align:center; padding: 20px; color: #646970;">
                            Nenhum insumo cadastrado. Clique no botão acima para adicionar o primeiro.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php 
                    $rowIndex = 0;
                    foreach ($ingredients as $ing): 
                        $packageSize = isset($ing->package_size) ? (float)$ing->package_size : (isset($ing->package_quantity) ? (float)$ing->package_quantity : 1.0);
                        $packageCost = isset($ing->package_cost) ? (float)$ing->package_cost : (isset($ing->cost) ? (float)$ing->cost : 0.0);
                        $category    = $ing->category ?? 'food';
                        $unit        = !empty($ing->unit) ? $ing->unit : 'g';
                        $unitCost    = ($packageSize > 0) ? ($packageCost / $packageSize) : 0;
                    ?>
                    <tr class="km-item-row">
                        <td>
                            <input type="hidden" name="ingredients[<?php echo $rowIndex; ?>][id]" value="<?php echo (int) $ing->id; ?>">
                            <input type="text" name="ingredients[<?php echo $rowIndex; ?>][name]" value="<?php echo esc_attr($ing->name); ?>" placeholder="Ex: Leite Condensado" class="widefat" required>
                        </td>
                        <td>
                            <select name="ingredients[<?php echo $rowIndex; ?>][category]" class="widefat">
                                <?php foreach ($categories as $catKey => $catLabel): ?>
                                    <option value="<?php echo esc_attr($catKey); ?>" <?php echo ($category === $catKey) ? 'selected' : ''; ?>>
                                        <?php echo esc_html($catLabel); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <input type="number" name="ingredients[<?php echo $rowIndex; ?>][package_cost]" value="<?php echo esc_attr($packageCost); ?>" step="0.01" min="0" class="widefat km-calc-cost" required>
                        </td>
                        <td>
                            <input type="number" name="ingredients[<?php echo $rowIndex; ?>][package_size]" value="<?php echo esc_attr($packageSize); ?>" step="0.0001" min="0.0001" class="widefat km-calc-size" required>
                        </td>
                        <td>
                            <select name="ingredients[<?php echo $rowIndex; ?>][unit]" class="widefat km-unit-select">
                                <option value="g" <?php echo ($unit === 'g') ? 'selected' : ''; ?>>g</option>
                                <option value="kg" <?php echo ($unit === 'kg') ? 'selected' : ''; ?>>kg</option>
                                <option value="ml" <?php echo ($unit === 'ml') ? 'selected' : ''; ?>>ml</option>
                                <option value="l" <?php echo ($unit === 'l') ? 'selected' : ''; ?>>L</option>
                                <option value="un" <?php echo ($unit === 'un') ? 'selected' : ''; ?>>un</option>
                                <option value="m" <?php echo ($unit === 'm') ? 'selected' : ''; ?>>m (metro)</option>
                            </select>
                        </td>
                        <td class="km-cost-preview" style="font-weight: 600; color: #1d2327;">
                            R$ <?php echo number_format($unitCost, 4, ',', '.'); ?> / <span class="km-unit-label"><?php echo esc_html($unit); ?></span>
                        </td>
                        <td style="text-align: center;">
                            <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=km_delete_ingredient&id=' . $ing->id), 'km_delete_ingredient_' . $ing->id)); ?>" 
                               class="button button-small" 
                               style="color: #b32d2e;"
                               onclick="return confirm('Deseja excluir este insumo?');">
                                🗑️
                            </a>
                        </td>
                    </tr>
                    <?php $rowIndex++; endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <div style="margin-top: 18px; display: flex; justify-content: flex-end;">
            <button type="submit" class="button button-primary button-large" style="padding: 0 30px; height: 42px; font-size: 15px;">
                💾 Salvar Todos os Insumos
            </button>
        </div>
    </form>
</div>

<style>
.km-ingredients-wrap { max-width: 1240px; margin-top: 20px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
.km-header-bar { background: #ffffff; padding: 16px 20px; border: 1px solid #ccd0d4; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; }
.km-header-bar h1 { margin: 0 0 4px 0; font-size: 22px; color: #1d2327; }
.km-header-bar p { margin: 0; color: #646970; font-size: 13px; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const tbody = document.getElementById('km-ingredients-tbody');
    const addBtn = document.getElementById('km-add-row-btn');

    function bindRow(row) {
        const costInput = row.querySelector('.km-calc-cost');
        const sizeInput = row.querySelector('.km-calc-size');
        const unitSelect = row.querySelector('.km-unit-select');
        const costPreview = row.querySelector('.km-cost-preview');
        const unitLabel = row.querySelector('.km-unit-label');

        function updateUnitCost() {
            const cost = parseFloat(costInput.value) || 0;
            const size = parseFloat(sizeInput.value) || 1;
            const unit = unitSelect.value;
            const unitCost = size > 0 ? (cost / size) : 0;

            if (unitLabel) unitLabel.textContent = unit;
            if (costPreview) {
                costPreview.innerHTML = 'R$ ' + unitCost.toFixed(4).replace('.', ',') + ' / ' + unit;
            }
        }

        if (costInput) costInput.addEventListener('input', updateUnitCost);
        if (sizeInput) sizeInput.addEventListener('input', updateUnitCost);
        if (unitSelect) unitSelect.addEventListener('change', updateUnitCost);
    }

    document.querySelectorAll('.km-item-row').forEach(bindRow);

    if (addBtn) {
        addBtn.addEventListener('click', function () {
            const emptyRow = document.querySelector('.km-row-empty');
            if (emptyRow) emptyRow.remove();

            // Get the next sequential index from existing rows
            const existingRows = document.querySelectorAll('.km-item-row');
            let nextIdx = existingRows.length;

            const tr = document.createElement('tr');
            tr.className = 'km-item-row';
            tr.innerHTML = `
                <td>
                    <input type="text" name="ingredients[${nextIdx}][name]" placeholder="Novo Insumo..." class="widefat" required>
                </td>
                <td>
                    <select name="ingredients[${nextIdx}][category]" class="widefat">
                        <option value="food">🍎 Alimento / Matéria-Prima</option>
                        <option value="packaging">📦 Embalagem & Descartável</option>
                        <option value="decoration">🌸 Decoração & Flores</option>
                        <option value="accessory">🎀 Acessório & Fitas / Tags</option>
                        <option value="other">🏷️ Outros Insumos</option>
                    </select>
                </td>
                <td>
                    <input type="number" name="ingredients[${nextIdx}][package_cost]" value="0.00" step="0.01" min="0" class="widefat km-calc-cost" required>
                </td>
                <td>
                    <input type="number" name="ingredients[${nextIdx}][package_size]" value="1.0000" step="0.0001" min="0.0001" class="widefat km-calc-size" required>
                </td>
                <td>
                    <select name="ingredients[${nextIdx}][unit]" class="widefat km-unit-select">
                        <option value="g">g</option>
                        <option value="kg">kg</option>
                        <option value="ml">ml</option>
                        <option value="l">L</option>
                        <option value="un">un</option>
                        <option value="m">m (metro)</option>
                    </select>
                </td>
                <td class="km-cost-preview" style="font-weight: 600; color: #1d2327;">
                    R$ 0,0000 / g
                </td>
                <td style="text-align: center;">
                    <button type="button" class="button button-small" style="color: #b32d2e;" onclick="this.closest('tr').remove();">🗑️</button>
                </td>
            `;
            tbody.appendChild(tr);
            bindRow(tr);
        });
    }
});
</script>